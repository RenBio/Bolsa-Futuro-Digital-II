// 1. Contador
let contador = 0;
const contadorSpan = document.getElementById('contador');
document.getElementById('aumentar').addEventListener('click', () => {
    contador++;
    contadorSpan.textContent = contador;
});
document.getElementById('diminuir').addEventListener('click', () => {
    contador--;
    contadorSpan.textContent = contador;
});

// 2. Validação de Formulário
document.getElementById('formulario').addEventListener('submit', function (event) {
    event.preventDefault(); // impede o envio do formulário
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const mensagem = document.getElementById('mensagem-formulario');

    if (nome === '' || email === '') {
        mensagem.textContent = 'Preencha todos os campos!';
    } else {
        mensagem.style.color = 'green';
        mensagem.textContent = 'Formulário enviado com sucesso!';
    }
});

// 3. Troca de Cor de Fundo
document.getElementById('mudar-cor').addEventListener('click', () => {
    const corAleatoria = '#' + Math.floor(Math.random() * 16777215).toString(16);
    document.body.style.backgroundColor = corAleatoria;
});

// 4. Lista Dinâmica
document.getElementById('adicionar-item').addEventListener('click', () => {
    const input = document.getElementById('item-lista');
    const valor = input.value.trim();

    if (valor !== '') {
        const li = document.createElement('li');
        li.textContent = valor;
        document.getElementById('lista').appendChild(li);
        input.value = '';
    }
});