document.getElementById("updateBtn").addEventListener("click", function() {
  const clientes = Math.floor(Math.random() * 1000);
  const vendas = Math.floor(Math.random() * 500);
  const estoque = Math.floor(Math.random() * 200);

  document.getElementById("clientes-count").textContent = clientes;
  document.getElementById("vendas-count").textContent = vendas;
  document.getElementById("estoque-count").textContent = estoque;
});
