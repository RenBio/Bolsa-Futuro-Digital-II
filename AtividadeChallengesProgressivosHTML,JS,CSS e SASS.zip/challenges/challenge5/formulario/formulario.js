const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const successMessage = document.getElementById("success-message");



emailInput.addEventListener("input",function() {
    const emailFeedback = document.getElementById("email-feedback");

if (emailInput.validity.valid) {
    emailFeedback.textContent = "Email válido!";
    emailFeedback.className = "success";
    } else {
    emailFeedback.textContent = "Error - Email inválido!";
    emailFeedback.className = "error";
    }

});

passwordInput.addEventListener("input", function() {
  const passwordFeedback = document.getElementById("password-feedback");

  if (passwordInput.value.length >= 6) {
    passwordFeedback.textContent = "Senha forte!";
    passwordFeedback.className = "success";
  } else {
    passwordFeedback.textContent = "A senha deve ter pelo menos 6 caracteres.";
    passwordFeedback.className = "error";
  }
});

form.addEventListener("submit", (e) => {
e.preventDefault();// Evita o envio real

const isEmailValid = emailInput.validity.valid;
const isPasswordValid = passwordInput.value.length >= 6;

if (isEmailValid && isPasswordValid) {
successMessage.classList.remove("hidden");
successMessage.classList.add("success");

form.reset();
    emailFeedback.textContent = "";
    passwordFeedback.textContent = "";
  } else {
    successMessage.classList.add("hidden");
  }


});


