const randomNumber = Math.floor(Math.random() * 100) + 1;
const feedbackElement = document.getElementById("feedback");
const submitGuessButton = document.getElementById("submitGuess");

submitGuessButton.addEventListener("click", function() {
  const userGuess = parseInt(document.getElementById("guess").value);

  if (userGuess === randomNumber) {
    feedbackElement.textContent = "Você acertou!";
    feedbackElement.style.color = "green";
  } else if (userGuess < randomNumber) {
    feedbackElement.textContent = "Tente um número maior.";
    feedbackElement.style.color = "orange";
  } else {
    feedbackElement.textContent = "Tente um número menor.";
    feedbackElement.style.color = "red";
  }
});
