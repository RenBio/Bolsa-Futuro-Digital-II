//
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

let player = { x: 10, y: 150, width: 10, height: 100, dy: 0 };
let ai = { x: canvas.width -10, y: 150, width: 10, height: 100 };
let ball = { x: 300, y: 200, size: 10, dx: 4, dy: 4 };
let playerScore = 0;
let aiScore = 0;

//Controles do game

//Controle do jogador

document.addEventListener("keydown", (e) => {
    if (e.key === "ArrowUp") player.dy = -6;
    if (e.key === "ArrowDown") player.dy = 6;

});

document.addEventListener("keyup", () => (player.dy = 0));

function drawRect(x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
}

function drawCircle(x, y, size, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();
}

function move() {
    player.y += player.dy;
// Limites do jogador
    if (player.y < 0) player.y = 0;
    if (player.y + player.height > canvas.height) {
         player.y = canvas.height - player.height;

}

ball.x += ball.dx;
ball.y += ball.dy;

// Rebater nas paredes
if (ball.y < 0 || ball.y > canvas.height) ball.dy *= -1;

// Movimento da IA

if (ai.y + ai.height / 2 < ball.y) ai.y += 4;
else ai.y -= 4;


// Colisões com raquete

// Colisão com  jogador
if (
    ball.x < player.x + player.width &&
    ball.x > player.x &&
    ball.y > player.y &&
    ball.y < player.y + player.height

) {
    ball.dx *= -1;
}

//colisão com Ai
if (
    ball.x + ball.size > ai.x &&
    ball.x < ai.x + ai.width &&
    ball.y > ai.y &&
    ball.y < ai.y + ai.height
) {
    ball.dx *= -1;
}

// Pontuação

if (ball.x < 0) {
    aiScore++;
    resetBall();
}

if (ball.x > canvas.width) {
    playerScore++;
    resetBall();
    }
}

function resetBall() {
    ball.x = canvas.width / 2;
    ball.y = canvas.height / 2;
    ball.dx *= -1;
    ball.dy = 4 * (Math.random() > 0.5 ? 1 : -1);
}

function drawScore() {
    document.getElementById('player-score').textContent = `Jogador: ${playerScore}`;
    document.getElementById('ai-score').textContent = `Computador:${aiScore}`;
}

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawRect(player.x, player.y, player.width, player.height, "white");
    drawRect(ai.x, ai.y, ai.width, ai.height, "white"); // I.A
    drawCircle(ball.x, ball.y, ball.size, "white"); // Bola
    drawScore();
    move();
    requestAnimationFrame(update);
}

update();