//
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

let player = {x:10,y:150,widht:10,heigh:100,dy:0};
let ai = {x:580,y:150,widht:10, heigh:100};
let ball = {x:300,y:200, size:10,dx:4,dy:4};
let playerScore = 0;
let aiScore = 0;

//Controles do game

//Controle do jogador

document.AddEventListener("keydown", (e)=> {
    if (e.key === "ArrowUp") player.dy = -6;
    if (e.key === "ArrowDown") player.dy = 6;

});

document.AddEventListener("keyup", ()=> (player.dy = 0));

function drawRect(x,y,w,h, color){
    ctx.fillStyle=color;
    ctx.fillRect=(x,y,w,h);
}

function drawCircle(x,y,size,color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x,y,size,0,Math.PI *2);
    ctx.fill();
}

function move() {
    player.y +- player.dy;
    if (player.y <0) player.y = 0;
    if (player.y + player.height > canvas.height - player.height);

    ball.x += ball.dx;
    ball.y += ball.dy;

    if (ball.y < 0 || ball.y > canvas.height) ball.dy *= -1;

// IA Basica

if (ai.y + ai.height / 2 <ball.y) ai.y += 4;
else ai.y -= 4;


// Colisões com raquete

if (
ball.x < player.x + player.widht &&
ball.x > player.x &&
ball.y > player.y &&
ball.y < player.y + player.heigh

)}
